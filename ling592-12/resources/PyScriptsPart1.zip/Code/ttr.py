#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ttr.py
# (C) 2010-2012 by Damir Cavar <dcavar@me.com>
# Type-token ratio


import sys, os, os.path, glob


delimiterSet = ";.,!?\"()':[]\n/+-—=≤≥{}><*’”“|"


def main(fname, data, lower):

	if not os.path.isfile(fname):
		print("Error: Not a file", fname)
		return

	try:
		inStream = open(fname, mode="r", encoding="utf-8")
		token = inStream.readline()
		while (token):
			token = token.strip()
			if lower:
				token = token.lower()
			if token not in delimiterSet:
				data[token] = data.get(token, 0) + 1
			token = inStream.readline()
		inStream.close()
	except IOError:
		print("Cannot read from file:", fname)


def relativizeData(data):
	reldata = {}
	total = float(sum(data.values()))
	if total == 0.0:
		return reldata
	for key, value in data.iteritems():
		reldata[key] = value/total
	return reldata


def typeTokenRatio(data):
	return 100 * (len(data.keys())/float(sum(data.values())))


def printData(data):
	for key, value in data.iteritems():
		print(key, value, sep="\t")


if __name__ == '__main__':
	data = {}
	for i in sys.argv[1:]:
		for j in glob.glob(i):
			main(os.path.expanduser(os.path.expandvars(j)), data, True)
			print("Type/Token ratio for ", j, ": ", typeTokenRatio(data))

