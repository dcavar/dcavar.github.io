#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# rfp-unique.py
# (C) 2010-2012 by Damir Cavar <dcavar@me.com>
# Simple generation of a relative frequency profiles from token lists


import sys, os, os.path, glob



delimiterSet = ";.,!?\"()':[]\n/+-—=≤≥{}><*’”“|"


models = []
ids    = []
sets   = []


def main(fname, lower):

	data = {}
	if not os.path.isfile(fname):
		print("Error: Not a file", fname)
		return

	try:
		inStream = open(fname, mode="r", encoding="utf-8")
		token = inStream.readline()
		while (token):
			token = token.strip()
			if lower:
				token = token.lower()
			if token not in delimiterSet:
				data[token] = data.get(token, 0) + 1
			token = inStream.readline()
		inStream.close()
	except IOError:
		print("Cannot read from file:", fname)
	return data


def relativizeData(idx):
	global models
	reldata = {}
	total = float(sum(models[idx].values()))
	if total == 0.0:
		return reldata
	for key, value in models[idx].items():
		reldata[key] = value/total
	models[idx] = reldata


def makeSets():
	global sets, models
	for i in range(len(models)):
		dictset = {}
		keys = set(models[i].keys())
		for j in range(len(models)):
			if j == i:
				continue
			keys = keys.difference(set(models[j].keys()))
		for j in keys:
			dictset[j] = models[i].get(j, 0)
		sets.append(dictset)


def printSets():
	global sets
	for i in range(len(sets)):
		# print ids[i]
		fname = os.path.splitext(ids[i])
		fname = fname[0] + "-unique-fset" + fname[1]
		try:
			oFl = open(fname, mode="w", encoding="utf-8")
			for key, val in sets[i].items():
				oFl.write(key)
				oFl.write("\t")
				oFl.write(str(val))
				oFl.write("\n")
			oFl.close()
		except IOError:
			print("Cannot write to file:", fname)


def printData(data):
	for key, value in data.iteritems():
		print(key, value, sep="\t")


if __name__ == '__main__':
	for i in sys.argv[1:]:
		for j in glob.glob(i):
			models.append(main(os.path.expanduser(os.path.expandvars(j)), True))
			ids.append(j)
	for i in range(len(models)):
		relativizeData(i)
	makeSets()
	printSets()
	
