#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# unique.py
# (C) 2010-2012 by Damir Cavar <dcavar@me.com>
# Simple generation of a relative frequency profiles from token lists
# lower-case normalization
# unique tokens per model


import sys, os, os.path, glob



delimiterSet = ";.,!?\"()':[]\n/+-—=≤≥{}><*’”“|"

models = []
ids    = []


def main(fname, lower):

	data = {}
	if not os.path.isfile(fname):
		print("Error: Not a file", fname)
		return data
	
	try:
		inStream = open(fname, mode="r", encoding="utf-8")
		token = inStream.readline()
		while (token):
			token = token.strip()
			if lower:
				token = token.lower()
			if token not in delimiterSet:
				data[token] = data.get(token, 0) + 1
			token = inStream.readline()
		inStream.close()
	except IOError:
		print("Cannot read from file:", fname)
	return data


def makeSets():
	global models
	mymodels = []
	for i in range(len(models)):
		keys = set(models[i].keys())
		for j in range(len(models)):
			if j == i:
				continue
			keys = keys.difference(set(models[j].keys()))
		mymodels.append(keys)
	models = mymodels


def printSets():
	global models
	for i in range(len(models)):
		fname = os.path.splitext(ids[i])
		fname = fname[0] + "-unique-set" + fname[1]
		try:
			oFl = open(fname, mode="w", encoding="utf-8")
			for j in models[i]:
				oFl.write(j)
				oFl.write("\n")
			oFl.close()
		except IOError:
			print("Cannot write to file:", fname)


def relativizeData(data):
	reldata = {}
	total = float(sum(data.values()))
	if total == 0.0:
		return reldata
	for key, value in data.items():
		reldata[key] = value/total
	return reldata


def printData(data):
	for key, value in data.items():
		print(key, value, sep="\t")


if __name__ == '__main__':
	data = {}
	for i in sys.argv[1:]:
		for j in glob.glob(i):
			models.append(main(os.path.expanduser(os.path.expandvars(j)), True))
			ids.append(j)
	makeSets()
	printSets()

