#!/usr/bin/env python
# -*- coding: utf-8 -*-

# rfp1.py
# (C) 2010 by Damir Cavar <dcavar@unizd.hr>
# Simple generation of a relative frequency profiles from token lists
# lower-case normalization

import sys, codecs, os, os.path, glob

# workaround for piping output
sys.stdout = codecs.getwriter('utf8')(sys.stdout)


delimiterSet = u";.,!?\"()':[]\n/+-—=≤≥{}><*’”“"


def main(fname, data, lower):

	if not os.path.isfile(fname):
		print "Error: Not a file", fname
		return

	try:
		inStream = codecs.open(fname, "r", "utf-8")
		token = inStream.readline()
		while (token):
			token = token.strip()
			if lower:
				token = token.lower()
			if token not in delimiterSet:
				data[token] = data.get(token, 0) + 1
			token = inStream.readline()
		inStream.close()
	except IOError:
		print "Cannot read from file:", fname


def relativizeData(data):
	reldata = {}
	total = float(sum(data.values()))
	if total == 0.0:
		return reldata
	for key, value in data.iteritems():
		reldata[key] = value/total
	return reldata


def printData(data):
	for key, value in data.iteritems():
		print "%s\t%.12f" % (key, value)


if __name__ == '__main__':
	data = {}
	for i in sys.argv[1:]:
		for j in glob.glob(i):
			main(os.path.expanduser(os.path.expandvars(j)), data, True)
	printData(relativizeData(data))
