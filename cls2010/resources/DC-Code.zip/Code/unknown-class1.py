#!/usr/bin/env python
# -*- coding: utf-8 -*-

# unknown-class1.py
# (C) 2010 by Damir Cavar <dcavar@unizd.hr>
# Simple model comparison


import sys, codecs, os, os.path, glob, fnmatch

# workaround for piping output
sys.stdout = codecs.getwriter('utf8')(sys.stdout)


delimiterSet = u";.,!?\"()':[]\n/+-—=≤≥{}><*’”“|"
digits = u"0123456789"
chars = u"abcdefghijklmnopqrstuvwxyz"
chars = u"".join( (chars, chars.upper()) )
spaces = u" \t\n"
numberdelimiters = u",."


models = []
ids    = []
sets   = []
unknown = {}



def tokenize(fname):
	global delimiterSet

	if not os.path.isfile(fname):
		print "Error: Not a file", fname
		return

	tokens = []
	try:
		inStream = codecs.open(fname, "r", "utf8")
		token = ""
		ch = inStream.read(1)
		lookahead = inStream.read(1)
		while True:
			if not ch:
				if token:
					tokens.append(token)
				break
			if ch in delimiterSet:
				if token:
					if token[-1] in digits and lookahead in digits and ch in numberdelimiters:
						token = "".join( (token, ch) )
					elif token[-1] in chars and lookahead in chars and ch in numberdelimiters:
						token = "".join( (token, ch) )
					else:
						tokens.append(token)
						token = ""
						if ch not in spaces:
							tokens.append(ch)
			elif ch in spaces:
				if token:
					tokens.append(token)
					token = ""
			else:
				token = "".join( (token, ch) )
			ch = lookahead
			lookahead = inStream.read(1)
		inStream.close()
	except IOError:
		print "Cannot read from file:", fname
	return tokens


def main(tokens, lower):
	data = {}
	for token in tokens:
		token = token.strip()
		if lower:
			token = token.lower()
		if token not in delimiterSet:
			data[token] = data.get(token, 0) + 1
	return data


def relativizeData(model):
	reldata = {}
	total = float(sum(model.values()))
	if total == 0.0:
		return reldata
	for key, value in model.iteritems():
		reldata[key] = value/total
	return reldata


def makeSets():
	global sets, models
	for i in range(len(models)):
		dictset = {}
		keys = set(models[i].keys())
		for j in range(len(models)):
			if j == i:
				continue
			keys = keys.difference(set(models[j].keys()))
		for j in keys:
			dictset[j] = models[i].get(j, 0)
		sets.append(dictset)


def printSets():
	global sets
	for i in range(len(sets)):
		fname = os.path.splitext(ids[i])
		fname = fname[0] + "-unique-fset" + fname[1]
		try:
			oFl = codecs.open(fname, "w", "utf-8")
			for key, val in sets[i].iteritems():
				oFl.write(key)
				oFl.write("\t")
				oFl.write(str(val))
				oFl.write("\n")
			oFl.close()
		except IOError:
			print "Cannot write to file:", fname


def compareWithModels(unknown):
	global models, ids
	errors = []
	for i in range(len(models)):
		compSet = set(unknown.keys())
		compSet = compSet.intersection(set(models[i].keys()))
		print "\n\nMatching %d tokens in unknown and %s" % (len(compSet), ids[i])
		for t in compSet:
			print t + " ",
		print ""
		error = 0.0
		for key, val in unknown.iteritems():
			if models[i].has_key(key):
				error += abs(val - models[i][key])
			else:
				error += 1.0
		errors.append(error)
		print "Error: %.6f" % (error)
	for i in range(len(errors)):
		print "Summary:"
		print "%s error: %.6f" % (ids[i], errors[i])



def loadModels():
	global models
	for file in os.listdir('.'):
		if fnmatch.fnmatch(file, "*unique-fset.lst"):
			mydict = {}
			try:
				inF = codecs.open(file, "r", "utf-8")
				token = inF.readline()
				while (token):
					token = token.strip()
					token = token.split()
					if len(token)==2:
						mydict[token[0]] = float(token[1])
					token = inF.readline()
				inF.close()
			except IOError:
				print "Cannot read from file:", file
			models.append(mydict)
			ids.append(file)


def printData(data):
	for key, value in data.iteritems():
		print "%s\t%.12f" % (key, value)


if __name__ == '__main__':
	loadModels()
	for i in sys.argv[1:]:
		for j in glob.glob(i):
			unknown = main(tokenize(os.path.expanduser(os.path.expandvars(j))), True)
			compareWithModels(relativizeData(unknown))

	
