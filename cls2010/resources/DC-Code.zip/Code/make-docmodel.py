#!/usr/bin/env python
# -*- coding: utf-8 -*-

# tokenizer.py
# (C) 2010 by Damir Cavar <dcavar@unizd.hr>
# Simple tokenization algorithm


import sys, codecs, os, os.path, glob, pickle


# workaround for piping output
sys.stdout = codecs.getwriter('utf8')(sys.stdout)


delimiterSet = u";.,!?\"()':[]\n/+-—=≤≥{}><*’”“|"
digits = u"0123456789"
chars = u"abcdefghijklmnopqrstuvwxyz"
chars = u"".join( (chars, chars.upper()) )
spaces = u" \t\n"
numberdelimiters = u",."


model = {}


def main(fname):
	global delimiterSet

	if not os.path.isfile(fname):
		print "Error: Not a file", fname
		return

	tokens = []
	try:
		inStream = codecs.open(fname, "r", "utf8")
		token = ""
		ch = inStream.read(1)
		lookahead = inStream.read(1)
		while True:
			if not ch:
				if token:
					tokens.append(token)
				break
			if ch in delimiterSet:
				if token:
					if token[-1] in digits and lookahead in digits and ch in numberdelimiters:
						token = "".join( (token, ch) )
					elif token[-1] in chars and lookahead in chars and ch in numberdelimiters:
						token = "".join( (token, ch) )
					else:
						tokens.append(token)
						token = ""
						if ch not in spaces:
							tokens.append(ch)
			elif ch in spaces:
				if token:
					tokens.append(token)
					token = ""
			else:
				token = "".join( (token, ch) )
			ch = lookahead
			lookahead = inStream.read(1)
		inStream.close()
	except IOError:
		print "Cannot read from file:", fname
	return tokens


def makeRelFreqProf(tokens, lower=True):
	global model

	for token in tokens:
		if token not in delimiterSet:
			if lower:
				token = token.lower()
			model[token] = model.get(token, 0) + 1


if __name__ == '__main__':
	count = 0
	for i in sys.argv[1:]:
		for j in glob.glob(i):
			# print j
			makeRelFreqProf(main(os.path.expanduser(os.path.expandvars(j))))
			count += 1
	model["__count__"] = count
	try:
		fp = open("model.dat", "wb")
		pickle.dump(model, fp)
		fp.close()
	except IOError:
		print "Cannot write to file: model.dat"

