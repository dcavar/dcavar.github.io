#!/usr/bin/env python
# -*- coding: utf-8 -*-

# tokenizer.py
# (C) 2010 by Damir Cavar <dcavar@unizd.hr>
# Simple tokenization algorithm


import sys, codecs, os, os.path, glob, pickle, fnmatch, math


# workaround for piping output
sys.stdout = codecs.getwriter('utf8')(sys.stdout)


delimiterSet = u";.,!?\"()':[]\n/+-—=≤≥{}><*’”“|"
digits = u"0123456789"
chars = u"abcdefghijklmnopqrstuvwxyz"
chars = u"".join( (chars, chars.upper()) )
spaces = u" \t\n"
numberdelimiters = u",."


models = []
ids = []
totalmodel = {}
countclass = []


def optimizeModels():
	global models, ids, totalmodel, countclass
	total = 0.0
	for i in range(len(models)):
		classtotal = 0.0
		for term, val in models[i].iteritems():
			if term == "__count__":
				continue
			total += val
			classtotal += val
			totalmodel[term] = totalmodel.get(term, 0) + val
		countclass.append(classtotal)
	result = {}
	i = 0
	print "model:", ids[i]
	for key, val in models[i].iteritems():
		# token - class
		if key == "__count__":
			continue
		mi =  (val / total) * math.log((total * val) / (totalmodel[key] * countclass[i]), 2)
		mi += ((countclass[i]-val)/total) * math.log((total * (countclass[i]-val)) / ((total - totalmodel[key]) * countclass[i]), 2)
		mi += ((totalmodel[key]-val)/total) * math.log((total - (totalmodel[key]-val)) / (totalmodel[key] * (total - countclass[i])) , 2)
		mi += ((total - countclass[i] - (totalmodel[key] - val)) / total) * math.log((total * (total - countclass[i] - (totalmodel[key] - val))) / ((total - totalmodel[key]) * (total - countclass[i])) , 2)
		print "%s\t%.10f" % (key, mi)


def loadModels():
	global models, ids
	for file in os.listdir('.'):
		if fnmatch.fnmatch(file, "*.dat"):
			try:
				mymodel = {}
				inF = open(file, "rb")
				models.append(pickle.load(inF))
				inF.close()
				ids.append(file)
			except IOError:
				print "Cannot read from file:", file


if __name__ == '__main__':
	loadModels()
	optimizeModels()
