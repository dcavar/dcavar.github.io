# entropy1.r
# (C) 2010 by Damir Cavar <dcavar@unizd.hr>

# load entropy library 
library("entropy")

# observed relative frequencies for each symbol
# a, b, c, d
x = c(0.25, 0.25, 0.25, 0.25)
y = c(0.1, 0.5, 0.2, 0.2)
z = c(0.01, 0.97, 0.01, 0.01)

# print the entropy for all distributions
entropy.plugin(x, unit="log2")
entropy.plugin(y, unit="log2")
entropy.plugin(z, unit="log2")

# print individual surprisal for b from each distribution
- 0.25 * log2(0.25)
- 0.5 * log2(0.5)
- 0.97 * log2(0.97)
