#!/usr/bin/env python


import sys
from math import log


def pentropy(distribution):
	for i in distribution:
		print i, - (distribution[i] * log(distribution[i], 2))


dist1 = {"a":0.25, "b":0.25, "c":0.25, "d":0.25}
dist2 = {"a":0.1,  "b":0.5,  "c":0.2,  "d":0.2}
dist3 = {"a":0.01, "b":0.97, "c":0.01, "d":0.01}


pentropy(dist1)
pentropy(dist2)
pentropy(dist3)
