#!/usr/bin/env python
# -*- coding: utf-8 -*-

# BM1.py
# (C) 2010 by Damir Cavar <dcavar@unizd.hr>
# Naive Bayesian 1


import sys, codecs, os, os.path, glob, fnmatch, pickle, math

# workaround for piping output
sys.stdout = codecs.getwriter('utf8')(sys.stdout)


delimiterSet = u";.,!?\"()':[]\n/+-—=≤≥{}><*’”“|"
digits = u"0123456789"
chars = u"abcdefghijklmnopqrstuvwxyz"
chars = u"".join( (chars, chars.upper()) )
spaces = u" \t\n"
numberdelimiters = u",."


models = []
ids = []
countDocsInClass = []
allNBModels = {}
priorsC = []


def tokenize(fname):
	global delimiterSet

	if not os.path.isfile(fname):
		print "Error: Not a file", fname
		return

	tokens = []
	try:
		inStream = codecs.open(fname, "r", "utf8")
		token = ""
		ch = inStream.read(1)
		lookahead = inStream.read(1)
		while True:
			if not ch:
				if token:
					tokens.append(token)
				break
			if ch in delimiterSet:
				if token:
					if token[-1] in digits and lookahead in digits and ch in numberdelimiters:
						token = "".join( (token, ch) )
					elif token[-1] in chars and lookahead in chars and ch in numberdelimiters:
						token = "".join( (token, ch) )
					else:
						tokens.append(token)
						token = ""
						if ch not in spaces:
							tokens.append(ch)
			elif ch in spaces:
				if token:
					tokens.append(token)
					token = ""
			else:
				token = "".join( (token, ch) )
			ch = lookahead
			lookahead = inStream.read(1)
		inStream.close()
	except IOError:
		print "Cannot read from file:", fname
	return tokens


def tokenList2Dict(tokens, lower=True):
	data = {}
	for token in tokens:
		token = token.strip()
		if lower:
			token = token.lower()
		if token not in delimiterSet:
			data[token] = data.get(token, 0) + 1
	return data


def relativizeData(data):
	reldata = {}
	total = float(sum(data.values()))
	if total == 0.0:
		return reldata
	for key, value in data.iteritems():
		reldata[key] = value/total
	return reldata



def applyMNNB(unkn):
	global allNBModels, priorsC, models
	result = []
	for i in range(len(models)):
		score = math.log(priorsC[i], 2)
		for key in unkn:
			if allNBModels.has_key(key):
				score += math.log(allNBModels[key][i])
		result.append(score)
	for i in range(len(result)):
		print "Model %s: score %.10f" % (ids[i], result[i])
	print "The winner is: %s\n" % (ids[result.index(max(result))])


def trainMNNB():
	global models, allNBModels, priorsC

	countDocs = 0
	tAllTerms = {}
	for i in range(len(models)):
		countDocs += models[i]["__count__"]
		for term, val in models[i].iteritems():
			if term == "__count__":
				continue
			tAllTerms[term] = tAllTerms.get(term, 0) + val
	totalTerms = float(sum(tAllTerms.values()))
	allTerms = {}
	for key, value in tAllTerms.iteritems():
		allTerms[key] = value/totalTerms
		allNBModels[key] = []
	tAllTerms = {}

	countCurrentDocs = 0
	for i in range(len(models)):
		countDocsInClass = models[i]["__count__"]
		priorC = float(countDocsInClass)/countDocs
		for term, val in allTerms.iteritems():
			condProb = float(models[i].get(term, 0) + 1)/(val + 1)
			nval = allNBModels.get(term, [])
			nval.append(condProb)
			allNBModels[term] = nval
		priorsC.append(priorC)


def loadModels():
	global models, ids
	for file in os.listdir('.'):
		if fnmatch.fnmatch(file, "*.dat"):
			try:
				mymodel = {}
				inF = open(file, "rb")
				models.append(pickle.load(inF))
				inF.close()
				tmp = os.path.splitext(file)
				ids.append(tmp[0])
			except IOError:
				print "Cannot read from file:", file


if __name__ == '__main__':
	loadModels()
	trainMNNB()
	for i in sys.argv[1:]:
		for j in glob.glob(i):
			print "Looking at:", j
			applyMNNB(tokenize(os.path.expanduser(os.path.expandvars(j))))


