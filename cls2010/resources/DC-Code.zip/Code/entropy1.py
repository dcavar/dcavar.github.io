#!/usr/bin/env python

import sys, math

def entropy(distribution):
	res = 0
	for i in distribution:
		res += distribution[i] * math.log(distribution[i], 2)
	print -res


dist1 = {"a":0.25, "b":0.25, "c":0.25, "d":0.25}
dist2 = {"a":0.2, "b":0.3, "c":0.25, "d":0.25}
dist3 = {"a":0.01, "b":0.01, "c":0.01, "d":0.97}

entropy(dist1)
entropy(dist2)
entropy(dist3)
