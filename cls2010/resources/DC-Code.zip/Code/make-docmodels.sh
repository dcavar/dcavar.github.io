#!/bin/sh
./make-docmodel.py sport*.txt
mv model.dat sports.dat
./make-docmodel.py tech*.txt
mv model.dat tech.dat
./make-docmodel.py nyt-books*.txt
mv model.dat nyt-books.dat

