#!/bin/sh
./tokenizer.py sport*.txt > sports.lst
./tokenizer.py tech*.txt > tech.lst
./tokenizer.py nyt-books*.txt > nyt.lst

