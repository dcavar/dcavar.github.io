#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# encoding: utf-8

"""
clean-stw.py
(C) 2012 by Damir Cavar (http://cavar.me/damir/)

Loads all words from all files given as parameters and
returnes a list of words alphabetically sorted without
duplicates.
"""


import sys, glob


def process(fname, tokens):
   try:
      ifp = open(fname, mode="r", encoding="utf8")
      tokens.update(ifp.read().split())
      ifp.close()
   except IOError:
      pass


if __name__ == "__main__":
   tokens = set()
   for i in sys.argv[1:]:
      for j in glob.glob(i):
         process(j, tokens)
   tokens = list(tokens)
   tokens.sort()
   for i in tokens:
      print(i)


